import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import type { WhatsAppSendRequest, WhatsAppSendResponse } from "@shared/api";
import { MessageCircle, ShieldCheck, Sparkles } from "lucide-react";

const schema = z.object({
  to: z
    .string()
    .trim()
    .min(8, "Enter a valid phone number")
    .regex(/^[+]?\d{7,15}$/i, "Use digits, optionally starting with + (E.164)"),
  message: z.string().trim().min(1, "Message is required").max(1000, "Max 1000 characters"),
});

type FormValues = z.infer<typeof schema>;

export default function Index() {
  const [loading, setLoading] = useState(false);
  const form = useForm<FormValues>({ resolver: zodResolver(schema), defaultValues: { to: "", message: "" } });

  const onSubmit = async (values: FormValues) => {
    setLoading(true);
    try {
      const payload: WhatsAppSendRequest = { to: values.to, message: values.message };
      const res = await fetch("/api/whatsapp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      // Parse response safely. Use clone() to avoid issues if something else reads the body.
      let data: WhatsAppSendResponse | null = null;
      try {
        data = (await res.clone().json()) as WhatsAppSendResponse;
      } catch (err) {
        // If JSON parsing fails or body already read, fallback to text
        try {
          const txt = await res.clone().text();
          data = (JSON.parse(txt) as WhatsAppSendResponse) ?? null;
        } catch (e) {
          data = null;
        }
      }

      if (res.ok && data && data.success) {
        toast.success("Message sent", { description: `ID: ${data.messageId}` });
        form.reset();
      } else {
        const msg = data ? (!data.success ? data.error?.message : "Failed to send") : `Unexpected response: ${res.status}`;
        toast.error("Send failed", { description: msg });
      }
    } catch (e: any) {
      toast.error("Network error", { description: e?.message || "Check your connection" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-emerald-100 dark:from-neutral-900 dark:via-neutral-950 dark:to-emerald-950 py-24 px-4">
      <section className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8 items-center">
        <div className="space-y-6">
          <div className="inline-flex items-center gap-2 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300 px-3 py-1 text-sm">
            <Sparkles className="w-4 h-4" />
            WhatsApp Cloud API Interface
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-emerald-900 dark:text-emerald-200">
            Send WhatsApp messages instantly
          </h1>
          <p className="text-emerald-900/80 dark:text-emerald-200/70 text-lg">
            A simple, secure interface for any user to send a message to a WhatsApp number. Production-ready, fast, and beautiful.
          </p>
          <ul className="grid gap-3 text-sm text-emerald-900/80 dark:text-emerald-200/80">
            <li className="flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-emerald-600"/>Secure server-side token handling</li>
            <li className="flex items-center gap-2"><MessageCircle className="w-4 h-4 text-emerald-600"/>Meta WhatsApp Cloud API</li>
          </ul>
        </div>

        <Card className="backdrop-blur supports-[backdrop-filter]:bg-white/60 dark:supports-[backdrop-filter]:bg-neutral-900/60 border-emerald-200/60 dark:border-emerald-800/40 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-emerald-900 dark:text-emerald-100">
              <MessageCircle className="w-5 h-5" />
              Send a message
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-5" onSubmit={form.handleSubmit(onSubmit)}>
              <div className="space-y-2">
                <Label htmlFor="to">Recipient number</Label>
                <Input id="to" placeholder="e.g. +15551234567" {...form.register("to")} />
                {form.formState.errors.to && (
                  <p className="text-sm text-red-600">{form.formState.errors.to.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea id="message" placeholder="Type your message..." rows={5} {...form.register("message")} />
                {form.formState.errors.message && (
                  <p className="text-sm text-red-600">{form.formState.errors.message.message}</p>
                )}
              </div>
              <Button type="submit" disabled={loading} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white">
                {loading ? "Sending..." : "Send via WhatsApp"}
              </Button>
              <p className="text-xs text-muted-foreground">
                Tip: Use international E.164 format with country code, e.g. +15551234567.
              </p>
            </form>
          </CardContent>
        </Card>
      </section>
    </main>
  );
}
