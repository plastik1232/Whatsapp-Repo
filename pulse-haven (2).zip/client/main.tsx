import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";

const container = document.getElementById("root");
if (container) {
  const anyContainer = container as any;
  if (!anyContainer.__appRoot) {
    anyContainer.__appRoot = createRoot(container);
  }
  anyContainer.__appRoot.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
} else {
  console.error("Root container not found");
}
