/**
 * Shared code between client and server
 * Useful to share types between client and server
 * and/or small pure JS functions that can be used on both client and server
 */

/**
 * Example response type for /api/demo
 */
export interface DemoResponse {
  message: string;
}

/**
 * Request payload for sending a WhatsApp message via our API
 */
export interface WhatsAppSendRequest {
  to: string; // E.164 format like +15551234567
  message: string; // message body
}

/**
 * Successful response from our API when sending WhatsApp messages
 */
export interface WhatsAppSendSuccess {
  success: true;
  messageId: string;
  to: string;
}

/**
 * Error response from our API
 */
export interface WhatsAppSendError {
  success: false;
  error: {
    code?: string | number;
    status?: number;
    message: string;
    details?: unknown;
  };
}

export type WhatsAppSendResponse = WhatsAppSendSuccess | WhatsAppSendError;
