import type { RequestHandler } from "express";
import type { WhatsAppSendRequest, WhatsAppSendResponse } from "@shared/api";

const WHATSAPP_GRAPH_API_VERSION = "v20.0";

function getEnv(name: string) {
  return process.env[name];
}

/**
 * Supports multiple providers selectable via SMS_PROVIDER env var.
 * - "meta" (default): Meta WhatsApp Cloud API
 * - "smssoft": generic SMSSoft provider (POST JSON {to,message} to SMSSOFT_URL)
 */
export const handleSendWhatsApp: RequestHandler = async (req, res) => {
  const { to, message } = (req.body || {}) as Partial<WhatsAppSendRequest>;

  if (!to || !message) {
    const resp: WhatsAppSendResponse = {
      success: false,
      error: { status: 400, message: "'to' and 'message' are required" },
    };
    return res.status(400).json(resp);
  }

  const provider = (getEnv("SMS_PROVIDER") || "meta").toLowerCase();

  if (provider === "meta") {
    const token = getEnv("META_WHATSAPP_TOKEN");
    const phoneId = getEnv("META_WHATSAPP_PHONE_ID");

    if (!token || !phoneId) {
      const resp: WhatsAppSendResponse = {
        success: false,
        error: {
          status: 500,
          message:
            "WhatsApp API is not configured. Please set META_WHATSAPP_TOKEN and META_WHATSAPP_PHONE_ID environment variables.",
        },
      };
      return res.status(500).json(resp);
    }

    try {
      const url = `https://graph.facebook.com/${WHATSAPP_GRAPH_API_VERSION}/${phoneId}/messages`;

      const waPayload = {
        messaging_product: "whatsapp",
        to,
        type: "text",
        text: { body: message },
      } as const;

      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(waPayload),
      });

      const data = (await response.json()) as any;

      if (!response.ok) {
        let sanitizedDetails: unknown = null;
        try {
          sanitizedDetails = JSON.parse(JSON.stringify(data));
        } catch (e) {
          sanitizedDetails = String(data ?? null);
        }

        const resp: WhatsAppSendResponse = {
          success: false,
          error: {
            status: response.status,
            message: data?.error?.message || "Failed to send message",
            details: sanitizedDetails,
          },
        };
        return res.status(response.status).json(resp);
      }

      const messageId = data?.messages?.[0]?.id ?? "unknown";

      const resp: WhatsAppSendResponse = {
        success: true,
        messageId,
        to,
      };

      return res.status(200).json(resp);
    } catch (err: any) {
      const resp: WhatsAppSendResponse = {
        success: false,
        error: {
          status: 500,
          message: err?.message || "Unexpected server error",
        },
      };
      return res.status(500).json(resp);
    }
  }

  if (provider === "smssoft") {
    const smsUrl = getEnv("SMSSOFT_URL");
    const smsKey = getEnv("SMSSOFT_API_KEY");
    const smsPriority = getEnv("SMSSOFT_PRIORITY") || "10";
    const smsType = getEnv("SMSSOFT_TYPE"); // optional
    const useGet = (getEnv("SMSSOFT_USE_GET") || "true").toLowerCase() === "true";

    if (!smsUrl || !smsKey) {
      const resp: WhatsAppSendResponse = {
        success: false,
        error: {
          status: 500,
          message:
            "SMSSoft provider is not configured. Please set SMSSOFT_URL and SMSSOFT_API_KEY environment variables.",
        },
      };
      return res.status(500).json(resp);
    }

    try {
      // SMSSoft expects query params like: ?api_key=XXX&mobile=92300...&priority=0&message=Hello
      if (useGet) {
        const url = new URL(smsUrl);
        url.searchParams.set("api_key", smsKey);
        // Ensure mobile uses no leading + and country code
        const mobile = String(to).startsWith("+") ? String(to).slice(1) : String(to);
        url.searchParams.set("mobile", mobile);
        url.searchParams.set("message", String(message));
        url.searchParams.set("priority", smsPriority);
        if (smsType) url.searchParams.set("type", smsType);

        const response = await fetch(url.toString(), { method: "GET" });

        let data: any = null;
        try {
          data = await response.json();
        } catch (e) {
          try {
            data = await response.text();
          } catch (e2) {
            data = null;
          }
        }

        if (!response.ok) {
          const resp: WhatsAppSendResponse = {
            success: false,
            error: {
              status: response.status,
              message: (data && (data.message || data.error)) || `SMSSoft request failed with status ${response.status}`,
              details: data ?? null,
            },
          };
          return res.status(response.status).json(resp);
        }

        const providerId = data?.messageId || data?.id || (typeof data === "string" ? data : null);
        const resp: WhatsAppSendResponse = {
          success: true,
          messageId: providerId ?? "smssoft:unknown",
          to,
        };
        return res.status(200).json(resp);
      }

      // Fallback: POST JSON body
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      const response = await fetch(smsUrl, {
        method: "POST",
        headers,
        body: JSON.stringify({ api_key: smsKey, mobile: to, message, priority: smsPriority }),
      });

      let data: any = null;
      try {
        data = await response.json();
      } catch (e) {
        try {
          data = await response.text();
        } catch (e2) {
          data = null;
        }
      }

      if (!response.ok) {
        const resp: WhatsAppSendResponse = {
          success: false,
          error: {
            status: response.status,
            message: (data && (data.message || data.error)) || `SMSSoft request failed with status ${response.status}`,
            details: data ?? null,
          },
        };
        return res.status(response.status).json(resp);
      }

      const providerId = data?.messageId || data?.id || (typeof data === "string" ? data : null);
      const resp: WhatsAppSendResponse = {
        success: true,
        messageId: providerId ?? "smssoft:unknown",
        to,
      };
      return res.status(200).json(resp);
    } catch (err: any) {
      const resp: WhatsAppSendResponse = {
        success: false,
        error: {
          status: 500,
          message: err?.message || "Unexpected server error",
        },
      };
      return res.status(500).json(resp);
    }
  }

  return res.status(400).json({ success: false, error: { status: 400, message: `Unknown SMS_PROVIDER '${provider}'` } });
};
